export default {
  expo: {
    name: "Taxi Chofer",
    slug: "taxi-driver",
    version: "0.1.0",
    orientation: "portrait",
    android: {
      package: "com.example.taxidriver",
      permissions: ["ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "ACCESS_BACKGROUND_LOCATION", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_LOCATION"]
    },
    ios: {
      bundleIdentifier: "com.example.taxidriver",
      infoPlist: { UIBackgroundModes: ["location"] }
    },
    plugins: [
      ["react-native-maps", {
        androidGoogleMapsApiKey: process.env.EXPO_PUBLIC_GOOGLE_MAPS_ANDROID_KEY,
        iosGoogleMapsApiKey: process.env.EXPO_PUBLIC_GOOGLE_MAPS_IOS_KEY
      }],
      ["expo-location", {
        locationWhenInUsePermission: "Permitir que Taxi Chofer use tu ubicación para mostrarte en el mapa.",
        locationAlwaysAndWhenInUsePermission: "Permitir que Taxi Chofer use tu ubicación durante el servicio para que la central y el pasajero vean el taxi en tiempo real.",
        isIosBackgroundLocationEnabled: true,
        isAndroidBackgroundLocationEnabled: true,
        isAndroidForegroundServiceEnabled: true
      }]
    ]
  }
};
