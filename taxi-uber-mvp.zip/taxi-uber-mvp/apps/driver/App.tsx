import './src/backgroundLocation';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Linking, SafeAreaView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from './src/supabase';
import { ensureTrackingStarted, stopTracking } from './src/backgroundLocation';

const DEFAULT_REGION: Region = { latitude: -33.044, longitude: -61.168, latitudeDelta: 0.08, longitudeDelta: 0.08 };

type Trip = { id:string; status:string; pickup_lat:number; pickup_lng:number; pickup_address:string|null; destination_lat:number; destination_lng:number; destination_address:string };

export default function App() {
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [userId,setUserId]=useState<string|null>(null); const [status,setStatus]=useState<'offline'|'available'|'busy'>('offline');
  const [trip,setTrip]=useState<Trip|null>(null); const [position,setPosition]=useState<Location.LocationObject|null>(null); const [loading,setLoading]=useState(false);

  const region = useMemo(() => position ? { latitude:position.coords.latitude, longitude:position.coords.longitude, latitudeDelta:0.02, longitudeDelta:0.02 } : DEFAULT_REGION,[position]);

  useEffect(()=>{ supabase.auth.getUser().then(({data})=>setUserId(data.user?.id ?? null)); const {data:l}=supabase.auth.onAuthStateChange((_e,s)=>setUserId(s?.user.id ?? null)); return ()=>l.subscription.unsubscribe(); },[]);

  useEffect(()=>{
    if(!userId) return;
    let watch: Location.LocationSubscription | undefined;
    const load=async()=>{
      const {data:p}=await supabase.from('profiles').select('role').eq('id',userId).single();
      if(p?.role!=='driver'){ Alert.alert('Acceso','Este usuario no está habilitado como chofer.'); await supabase.auth.signOut(); return; }
      const {data:d}=await supabase.from('drivers').select('status').eq('user_id',userId).single(); if(d) setStatus(d.status);
      const {data:t}=await supabase.from('trips').select('*').eq('driver_id',userId).in('status',['assigned','driver_en_route','arrived','in_trip']).order('created_at',{ascending:false}).limit(1).maybeSingle(); setTrip(t as Trip|null);
      const perm=await Location.requestForegroundPermissionsAsync();
      if(perm.status==='granted') watch=await Location.watchPositionAsync({accuracy:Location.Accuracy.High,timeInterval:3000,distanceInterval:5},setPosition);
    };
    load();
    const ch=supabase.channel(`driver-${userId}`)
      .on('postgres_changes',{event:'*',schema:'public',table:'drivers',filter:`user_id=eq.${userId}`},(p:any)=>setStatus(p.new?.status ?? 'offline'))
      .on('postgres_changes',{event:'*',schema:'public',table:'trips',filter:`driver_id=eq.${userId}`},async()=>{
        const {data:t}=await supabase.from('trips').select('*').eq('driver_id',userId).in('status',['assigned','driver_en_route','arrived','in_trip']).order('created_at',{ascending:false}).limit(1).maybeSingle(); setTrip(t as Trip|null);
      }).subscribe();
    return()=>{watch?.remove(); supabase.removeChannel(ch);};
  },[userId]);

  async function login(){ setLoading(true); const {error}=await supabase.auth.signInWithPassword({email,password}); setLoading(false); if(error) Alert.alert('Error',error.message); }
  async function setAvailability(next:'offline'|'available'){
    try{ setLoading(true); const {error}=await supabase.rpc('driver_set_availability',{p_status:next}); if(error) throw error; if(next==='available') await ensureTrackingStarted(); else await stopTracking(); }
    catch(e:any){Alert.alert('No se pudo cambiar el estado',e.message);} finally{setLoading(false);}
  }
  async function advance(next:string){ if(!trip)return; const {error}=await supabase.rpc('driver_set_trip_status',{p_trip_id:trip.id,p_status:next}); if(error) Alert.alert('Error',error.message); }
  function navigate(){ if(!trip)return; const dest=trip.status==='assigned'||trip.status==='driver_en_route' ? `${trip.pickup_lat},${trip.pickup_lng}` : `${trip.destination_lat},${trip.destination_lng}`; Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${dest}&travelmode=driving`); }

  if(!userId) return <SafeAreaView style={s.login}><Text style={s.logo}>Taxi Chofer</Text><TextInput style={s.input} autoCapitalize="none" placeholder="Email" value={email} onChangeText={setEmail}/><TextInput style={s.input} secureTextEntry placeholder="Contraseña" value={password} onChangeText={setPassword}/><TouchableOpacity style={s.primary} onPress={login} disabled={loading}><Text style={s.primaryText}>{loading?'Ingresando...':'Ingresar'}</Text></TouchableOpacity></SafeAreaView>;

  return <SafeAreaView style={s.container}>
    <View style={s.header}><View><Text style={s.title}>Chofer</Text><Text style={s.sub}>Estado: {status}</Text></View><TouchableOpacity onPress={()=>supabase.auth.signOut()}><Text>Salir</Text></TouchableOpacity></View>
    <MapView provider={PROVIDER_GOOGLE} style={s.map} region={region} showsUserLocation>
      {trip && <><Marker coordinate={{latitude:trip.pickup_lat,longitude:trip.pickup_lng}} title="Pasajero" pinColor="orange"/><Marker coordinate={{latitude:trip.destination_lat,longitude:trip.destination_lng}} title="Destino" pinColor="purple"/></>}
    </MapView>
    <View style={s.panel}>
      {!trip ? <>
        <Text style={s.panelTitle}>{status==='available'?'Estás disponible':'Fuera de servicio'}</Text>
        {status==='offline' ? <TouchableOpacity style={s.green} onPress={()=>setAvailability('available')}><Text style={s.btnText}>Comenzar servicio</Text></TouchableOpacity> : <TouchableOpacity style={s.gray} onPress={()=>setAvailability('offline')}><Text style={s.btnText}>Finalizar servicio</Text></TouchableOpacity>}
      </> : <>
        <Text style={s.panelTitle}>Viaje asignado</Text><Text>Retiro: {trip.pickup_address||'Ubicación en mapa'}</Text><Text>Destino: {trip.destination_address}</Text>
        <TouchableOpacity style={s.dark} onPress={navigate}><Text style={s.btnText}>Abrir navegación</Text></TouchableOpacity>
        {trip.status==='assigned' && <TouchableOpacity style={s.primary} onPress={()=>advance('driver_en_route')}><Text style={s.primaryText}>Voy al pasajero</Text></TouchableOpacity>}
        {trip.status==='driver_en_route' && <TouchableOpacity style={s.primary} onPress={()=>advance('arrived')}><Text style={s.primaryText}>Llegué</Text></TouchableOpacity>}
        {trip.status==='arrived' && <TouchableOpacity style={s.primary} onPress={()=>advance('in_trip')}><Text style={s.primaryText}>Iniciar viaje</Text></TouchableOpacity>}
        {trip.status==='in_trip' && <TouchableOpacity style={s.green} onPress={()=>advance('completed')}><Text style={s.btnText}>Finalizar viaje</Text></TouchableOpacity>}
      </>}
    </View>
  </SafeAreaView>;
}

const s=StyleSheet.create({container:{flex:1,backgroundColor:'#fff'},login:{flex:1,padding:24,justifyContent:'center',gap:12},logo:{fontSize:34,fontWeight:'800',marginBottom:12},input:{borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:14,fontSize:16},primary:{backgroundColor:'#111827',padding:15,borderRadius:12,alignItems:'center',marginTop:8},primaryText:{color:'#fff',fontWeight:'700'},header:{padding:16,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},title:{fontSize:24,fontWeight:'800'},sub:{color:'#6b7280'},map:{flex:1},panel:{padding:16,gap:10,borderTopWidth:1,borderColor:'#eee'},panelTitle:{fontSize:18,fontWeight:'800'},green:{backgroundColor:'#16a34a',padding:15,borderRadius:12,alignItems:'center'},gray:{backgroundColor:'#6b7280',padding:15,borderRadius:12,alignItems:'center'},dark:{backgroundColor:'#374151',padding:13,borderRadius:12,alignItems:'center'},btnText:{color:'#fff',fontWeight:'700'}});
