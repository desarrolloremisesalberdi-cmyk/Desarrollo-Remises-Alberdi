import * as TaskManager from 'expo-task-manager';
import * as Location from 'expo-location';
import { supabase } from './supabase';

export const LOCATION_TASK = 'taxi-driver-location-task';

TaskManager.defineTask(LOCATION_TASK, async ({ data, error }) => {
  if (error || !data) return;
  const locations = (data as { locations: Location.LocationObject[] }).locations;
  const loc = locations?.[locations.length - 1];
  if (!loc) return;

  const { data: auth } = await supabase.auth.getUser();
  const user = auth.user;
  if (!user) return;

  await supabase.from('driver_locations').upsert({
    driver_id: user.id,
    lat: loc.coords.latitude,
    lng: loc.coords.longitude,
    heading: loc.coords.heading,
    speed: loc.coords.speed,
    accuracy: loc.coords.accuracy,
    updated_at: new Date().toISOString()
  });
});

export async function ensureTrackingStarted() {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') throw new Error('Se necesita permiso de ubicación.');
  const bg = await Location.requestBackgroundPermissionsAsync();
  if (bg.status !== 'granted') throw new Error('Se necesita permiso de ubicación en segundo plano para el servicio.');
  const active = await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK);
  if (!active) {
    await Location.startLocationUpdatesAsync(LOCATION_TASK, {
      accuracy: Location.Accuracy.BestForNavigation,
      timeInterval: 5000,
      distanceInterval: 10,
      pausesUpdatesAutomatically: false,
      showsBackgroundLocationIndicator: true,
      foregroundService: {
        notificationTitle: 'Taxi en servicio',
        notificationBody: 'Compartiendo ubicación con la central.'
      }
    });
  }
}

export async function stopTracking() {
  if (await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK)) {
    await Location.stopLocationUpdatesAsync(LOCATION_TASK);
  }
}
