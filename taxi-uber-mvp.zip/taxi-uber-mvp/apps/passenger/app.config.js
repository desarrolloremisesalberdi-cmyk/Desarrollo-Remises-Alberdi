export default {
  expo: {
    name: "Taxi Pasajero",
    slug: "taxi-passenger",
    version: "0.1.0",
    orientation: "portrait",
    android: { package: "com.example.taxipassenger" },
    ios: { bundleIdentifier: "com.example.taxipassenger" },
    plugins: [
      ["react-native-maps", {
        androidGoogleMapsApiKey: process.env.EXPO_PUBLIC_GOOGLE_MAPS_ANDROID_KEY,
        iosGoogleMapsApiKey: process.env.EXPO_PUBLIC_GOOGLE_MAPS_IOS_KEY
      }],
      ["expo-location", {
        locationWhenInUsePermission: "Permitir que Taxi Pasajero use tu ubicación para solicitar un vehículo."
      }]
    ]
  }
};
