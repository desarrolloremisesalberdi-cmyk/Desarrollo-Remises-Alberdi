import React, { useEffect, useMemo, useState } from 'react';
import { Alert, SafeAreaView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from './src/supabase';

const DEFAULT_REGION: Region = { latitude:-33.044, longitude:-61.168, latitudeDelta:0.08, longitudeDelta:0.08 };
type Trip={id:string;driver_id:string|null;status:string;pickup_lat:number;pickup_lng:number;destination_address:string;destination_lat:number;destination_lng:number};
type DriverLoc={lat:number;lng:number;updated_at:string};

export default function App(){
  const [mode,setMode]=useState<'login'|'signup'>('login'); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [fullName,setFullName]=useState(''); const [phone,setPhone]=useState(''); const [userId,setUserId]=useState<string|null>(null);
  const [position,setPosition]=useState<Location.LocationObject|null>(null); const [destination,setDestination]=useState(''); const [trip,setTrip]=useState<Trip|null>(null); const [driverLoc,setDriverLoc]=useState<DriverLoc|null>(null); const [loading,setLoading]=useState(false);

  const region=useMemo(()=>position?{latitude:position.coords.latitude,longitude:position.coords.longitude,latitudeDelta:0.03,longitudeDelta:0.03}:DEFAULT_REGION,[position]);
  useEffect(()=>{ supabase.auth.getUser().then(({data})=>setUserId(data.user?.id??null)); const {data:l}=supabase.auth.onAuthStateChange((_e,s)=>setUserId(s?.user.id??null)); return()=>l.subscription.unsubscribe();},[]);

  useEffect(()=>{
    if(!userId)return;
    Location.requestForegroundPermissionsAsync().then(async p=>{if(p.status==='granted') setPosition(await Location.getCurrentPositionAsync({accuracy:Location.Accuracy.High}));});
    const load=async()=>{const {data}=await supabase.from('trips').select('*').eq('passenger_id',userId).in('status',['requested','assigned','driver_en_route','arrived','in_trip']).order('created_at',{ascending:false}).limit(1).maybeSingle(); setTrip(data as Trip|null);};
    load();
    const ch=supabase.channel(`passenger-${userId}`).on('postgres_changes',{event:'*',schema:'public',table:'trips',filter:`passenger_id=eq.${userId}`},load).subscribe();
    return()=>{supabase.removeChannel(ch);};
  },[userId]);

  useEffect(()=>{
    setDriverLoc(null); if(!trip?.driver_id)return;
    const id=trip.driver_id;
    const load=async()=>{const {data}=await supabase.from('driver_locations').select('lat,lng,updated_at').eq('driver_id',id).maybeSingle(); setDriverLoc(data as DriverLoc|null);};
    load(); const ch=supabase.channel(`driverloc-${id}`).on('postgres_changes',{event:'*',schema:'public',table:'driver_locations',filter:`driver_id=eq.${id}`},(p:any)=>setDriverLoc(p.new as DriverLoc)).subscribe();
    return()=>{supabase.removeChannel(ch);};
  },[trip?.driver_id]);

  async function login(){setLoading(true);const {error}=await supabase.auth.signInWithPassword({email,password});setLoading(false);if(error)Alert.alert('Error',error.message);}
  async function signup(){setLoading(true);const {error}=await supabase.auth.signUp({email,password,options:{data:{full_name:fullName,phone}}});setLoading(false);if(error)Alert.alert('Error',error.message);else Alert.alert('Cuenta creada','Si Supabase exige confirmación de email, revisá tu correo.');}
  async function requestTrip(){
    if(!position)return Alert.alert('Ubicación','No pudimos obtener tu ubicación.'); if(destination.trim().length<4)return Alert.alert('Destino','Escribí una dirección.');
    try{setLoading(true); const {data:g,error:ge}=await supabase.functions.invoke('geocode',{body:{address:`${destination}, Casilda, Santa Fe, Argentina`}}); if(ge||g?.error)throw new Error(g?.error||ge?.message);
      const payload={passenger_id:userId,pickup_address:'Mi ubicación',pickup_lat:position.coords.latitude,pickup_lng:position.coords.longitude,destination_address:g.formattedAddress,destination_lat:g.lat,destination_lng:g.lng,status:'requested'};
      const {data:t,error}=await supabase.from('trips').insert(payload).select().single(); if(error)throw error; setTrip(t as Trip); setDestination('');
    }catch(e:any){Alert.alert('No se pudo pedir el taxi',e.message);}finally{setLoading(false);}
  }
  async function cancel(){if(!trip)return;const {error}=await supabase.rpc('passenger_cancel_trip',{p_trip_id:trip.id});if(error)Alert.alert('Error',error.message);}

  if(!userId)return <SafeAreaView style={s.login}><Text style={s.logo}>Taxi Pasajero</Text>{mode==='signup'&&<><TextInput style={s.input} placeholder="Nombre y apellido" value={fullName} onChangeText={setFullName}/><TextInput style={s.input} placeholder="Teléfono" keyboardType="phone-pad" value={phone} onChangeText={setPhone}/></>}<TextInput style={s.input} autoCapitalize="none" placeholder="Email" value={email} onChangeText={setEmail}/><TextInput style={s.input} secureTextEntry placeholder="Contraseña" value={password} onChangeText={setPassword}/><TouchableOpacity style={s.primary} onPress={mode==='login'?login:signup}><Text style={s.primaryText}>{loading?'Procesando...':mode==='login'?'Ingresar':'Crear cuenta'}</Text></TouchableOpacity><TouchableOpacity onPress={()=>setMode(mode==='login'?'signup':'login')}><Text style={s.link}>{mode==='login'?'Crear una cuenta':'Ya tengo una cuenta'}</Text></TouchableOpacity></SafeAreaView>;

  return <SafeAreaView style={s.container}><View style={s.header}><View><Text style={s.title}>Pedí tu taxi</Text><Text style={s.sub}>{trip?`Estado: ${trip.status}`:'Sin viaje activo'}</Text></View><TouchableOpacity onPress={()=>supabase.auth.signOut()}><Text>Salir</Text></TouchableOpacity></View>
    <MapView provider={PROVIDER_GOOGLE} style={s.map} region={region} showsUserLocation>
      {trip&&<Marker coordinate={{latitude:trip.destination_lat,longitude:trip.destination_lng}} title="Destino" pinColor="purple"/>}
      {driverLoc&&<Marker coordinate={{latitude:driverLoc.lat,longitude:driverLoc.lng}} title="Tu taxi" pinColor="green"/>}
    </MapView>
    <View style={s.panel}>{!trip?<><TextInput style={s.input} placeholder="¿A dónde vas? Ej.: Buenos Aires 1234" value={destination} onChangeText={setDestination}/><TouchableOpacity style={s.primary} onPress={requestTrip} disabled={loading}><Text style={s.primaryText}>{loading?'Buscando...':'Pedir taxi'}</Text></TouchableOpacity></>:<><Text style={s.panelTitle}>Viaje en curso</Text><Text>Destino: {trip.destination_address}</Text><Text>{trip.driver_id?'Taxi asignado. Podés verlo en el mapa.':'Esperando asignación de la central...'}</Text>{['requested','assigned','driver_en_route'].includes(trip.status)&&<TouchableOpacity style={s.cancel} onPress={cancel}><Text style={s.primaryText}>Cancelar viaje</Text></TouchableOpacity>}</>}</View>
  </SafeAreaView>;
}

const s=StyleSheet.create({container:{flex:1,backgroundColor:'#fff'},login:{flex:1,padding:24,justifyContent:'center',gap:12},logo:{fontSize:34,fontWeight:'800',marginBottom:12},input:{borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:14,fontSize:16},primary:{backgroundColor:'#111827',padding:15,borderRadius:12,alignItems:'center'},primaryText:{color:'#fff',fontWeight:'700'},link:{textAlign:'center',color:'#2563eb',padding:8},header:{padding:16,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},title:{fontSize:24,fontWeight:'800'},sub:{color:'#6b7280'},map:{flex:1},panel:{padding:16,gap:10,borderTopWidth:1,borderColor:'#eee'},panelTitle:{fontWeight:'800',fontSize:18},cancel:{backgroundColor:'#dc2626',padding:13,borderRadius:12,alignItems:'center'}});
