import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { APIProvider, Map as GoogleMap, Marker } from '@vis.gl/react-google-maps';
import { supabase } from './supabase';
import './styles.css';

type Driver={user_id:string;status:'offline'|'available'|'busy';vehicle_label:string|null;plate:string|null;name?:string;lat?:number;lng?:number;updated_at?:string};
type Trip={id:string;passenger_id:string;driver_id:string|null;status:string;pickup_address:string|null;pickup_lat:number;pickup_lng:number;destination_address:string;destination_lat:number;destination_lng:number;created_at:string};

const center={lat:-33.044,lng:-61.168};
const statusLabel:Record<string,string>={requested:'Solicitado',assigned:'Asignado',driver_en_route:'Chofer en camino',arrived:'Chofer llegó',in_trip:'En viaje',completed:'Finalizado',cancelled:'Cancelado'};

function markerIcon(status:Driver['status']){
  const color=status==='available'?'#16a34a':status==='busy'?'#dc2626':'#6b7280';
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46"><circle cx="23" cy="23" r="20" fill="${color}" stroke="white" stroke-width="3"/><text x="23" y="30" text-anchor="middle" font-size="22">🚕</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function App(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [userId,setUserId]=useState<string|null>(null);
  const [drivers,setDrivers]=useState<Driver[]>([]); const [trips,setTrips]=useState<Trip[]>([]); const [loading,setLoading]=useState(false); const [error,setError]=useState('');

  useEffect(()=>{supabase.auth.getUser().then(({data})=>setUserId(data.user?.id??null));const{data:l}=supabase.auth.onAuthStateChange((_e,s)=>setUserId(s?.user.id??null));return()=>l.subscription.unsubscribe();},[]);

  async function loadAll(){
    const [{data:d,error:de},{data:l,error:le},{data:p,error:pe},{data:t,error:te}]=await Promise.all([
      supabase.from('drivers').select('*'),
      supabase.from('driver_locations').select('*'),
      supabase.from('profiles').select('id,full_name,role').eq('role','driver'),
      supabase.from('trips').select('*').in('status',['requested','assigned','driver_en_route','arrived','in_trip']).order('created_at',{ascending:true})
    ]);
    if(de||le||pe||te){setError(de?.message||le?.message||pe?.message||te?.message||'Error');return;}
    const locMap=new Map((l||[]).map((x:any)=>[x.driver_id,x])); const nameMap=new Map((p||[]).map((x:any)=>[x.id,x.full_name]));
    setDrivers((d||[]).map((x:any)=>({...x,name:nameMap.get(x.user_id)||'Chofer',...(locMap.get(x.user_id)||{})})));
    setTrips((t||[]) as Trip[]);
  }

  useEffect(()=>{
    if(!userId)return; (async()=>{const{data:p}=await supabase.from('profiles').select('role').eq('id',userId).single();if(p?.role!=='operator'){setError('Este usuario no tiene rol de operador.');return;}await loadAll();})();
    const ch=supabase.channel('operator-dashboard').on('postgres_changes',{event:'*',schema:'public',table:'driver_locations'},loadAll).on('postgres_changes',{event:'*',schema:'public',table:'drivers'},loadAll).on('postgres_changes',{event:'*',schema:'public',table:'trips'},loadAll).subscribe();
    return()=>{supabase.removeChannel(ch);};
  },[userId]);

  async function login(e:React.FormEvent){e.preventDefault();setLoading(true);setError('');const{error}=await supabase.auth.signInWithPassword({email,password});if(error)setError(error.message);setLoading(false);}
  async function assign(tripId:string,driverId:string){if(!driverId)return;const{error}=await supabase.rpc('operator_assign_trip',{p_trip_id:tripId,p_driver_id:driverId});if(error)alert(error.message);}
  const available=useMemo(()=>drivers.filter(d=>d.status==='available'),[drivers]);

  if(!userId)return <div className="login-shell"><form className="login-card" onSubmit={login}><div className="badge">CENTRAL</div><h1>Operador de taxis</h1><p>Ingresá con el usuario operador de Supabase.</p><input placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)}/><input placeholder="Contraseña" type="password" value={password} onChange={e=>setPassword(e.target.value)}/>{error&&<div className="error">{error}</div>}<button>{loading?'Ingresando...':'Ingresar'}</button></form></div>;

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="side-head"><div><div className="badge">CENTRAL</div><h2>Despacho</h2></div><button className="ghost" onClick={()=>supabase.auth.signOut()}>Salir</button></div>
      {error&&<div className="error">{error}</div>}
      <div className="stats"><div><b>{drivers.filter(d=>d.status==='available').length}</b><span>Libres</span></div><div><b>{drivers.filter(d=>d.status==='busy').length}</b><span>Ocupados</span></div><div><b>{trips.filter(t=>t.status==='requested').length}</b><span>Esperando</span></div></div>
      <h3>Viajes activos</h3>
      <div className="trip-list">{trips.length===0&&<p className="muted">No hay viajes activos.</p>}{trips.map(t=><div className="trip" key={t.id}><div className="trip-top"><strong>{statusLabel[t.status]||t.status}</strong><span>{new Date(t.created_at).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})}</span></div><small>Retiro</small><div>{t.pickup_address||`${t.pickup_lat.toFixed(5)}, ${t.pickup_lng.toFixed(5)}`}</div><small>Destino</small><div>{t.destination_address}</div>{t.status==='requested'?<div className="assign"><select defaultValue="" onChange={e=>e.target.value&&assign(t.id,e.target.value)}><option value="" disabled>Asignar chofer...</option>{available.map(d=><option key={d.user_id} value={d.user_id}>{d.vehicle_label||d.name||'Chofer'} {d.plate?`(${d.plate})`:''}</option>)}</select></div>:<div className="assigned">Chofer: {drivers.find(d=>d.user_id===t.driver_id)?.vehicle_label||drivers.find(d=>d.user_id===t.driver_id)?.name||'Asignado'}</div>}</div>)}</div>
    </aside>
    <main className="map-wrap">
      <APIProvider apiKey={import.meta.env.VITE_GOOGLE_MAPS_WEB_KEY} region="AR" language="es">
        <GoogleMap defaultCenter={center} defaultZoom={14} gestureHandling="greedy" disableDefaultUI={false}>
          {drivers.filter(d=>typeof d.lat==='number'&&typeof d.lng==='number').map(d=><Marker key={d.user_id} position={{lat:d.lat!,lng:d.lng!}} title={`${d.vehicle_label||d.name||'Taxi'} - ${d.status}`} icon={markerIcon(d.status)} />)}
          {trips.filter(t=>t.status==='requested').map(t=><Marker key={`pickup-${t.id}`} position={{lat:t.pickup_lat,lng:t.pickup_lng}} title="Pasajero esperando" label="P" />)}
        </GoogleMap>
      </APIProvider>
      <div className="legend"><span><i className="dot green"></i>Libre</span><span><i className="dot red"></i>Ocupado</span><span><i className="dot gray"></i>Fuera de servicio</span><p>El color se muestra en la lista lateral; los marcadores se actualizan por Supabase Realtime.</p></div>
      <div className="driver-strip">{drivers.map(d=><div className={`driver-card ${d.status}`} key={d.user_id}><strong>{d.vehicle_label||d.name||'Taxi'}</strong><span>{d.plate||'Sin patente'}</span><small>{d.status==='available'?'LIBRE':d.status==='busy'?'OCUPADO':'FUERA DE SERVICIO'}</small></div>)}</div>
    </main>
  </div>;
}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
