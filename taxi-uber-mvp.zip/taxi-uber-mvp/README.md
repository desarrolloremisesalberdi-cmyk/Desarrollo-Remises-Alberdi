# Taxi / Uber-like MVP

Monorepo con 3 aplicaciones separadas:

- `apps/driver`: app móvil del chofer (Expo + React Native)
- `apps/passenger`: app móvil del pasajero (Expo + React Native)
- `apps/operator`: central web del operador (React + Vite)
- `supabase`: base de datos, RLS y funciones para Google Geocoding / Routes

## Qué hace este MVP

### Chofer
- Inicio de sesión con Supabase Auth.
- Cambia estado: fuera de servicio / libre / ocupado.
- Publica ubicación GPS en Supabase cada ~5 segundos o 10 metros.
- Puede seguir reportando ubicación en segundo plano en build nativo.
- Ve su posición en Google Maps.
- Ve el viaje asignado en tiempo real.

### Pasajero
- Inicio de sesión.
- Obtiene ubicación actual.
- Escribe destino.
- Convierte dirección a coordenadas usando una Edge Function (`geocode`).
- Crea un pedido de viaje.
- Ve el estado del viaje y el taxi asignado en tiempo real.

### Operador
- Inicio de sesión.
- Mapa web con los taxis en vivo.
- Verde = libre, rojo = ocupado, gris = fuera de servicio.
- Lista de viajes pendientes y en curso.
- Asignación manual de un chofer disponible a un viaje.

## Arquitectura

GPS del chofer -> Supabase `driver_locations` -> Realtime -> operador/pasajero.

El movimiento del marcador NO llama a Google Routes en cada actualización. Google Maps dibuja el mapa; Supabase transmite las coordenadas.

## 1. Crear la base de datos

1. Crear un proyecto en Supabase.
2. Abrir SQL Editor.
3. Ejecutar `supabase/schema.sql` completo.
4. En Authentication, crear los usuarios o permitir registro por email.

Para el primer operador, crear su usuario en Supabase Auth y luego ejecutar:

```sql
update public.profiles
set role = 'operator'
where id = 'UUID_DEL_USUARIO';
```

Para un chofer:

```sql
update public.profiles
set role = 'driver'
where id = 'UUID_DEL_USUARIO';

insert into public.drivers (user_id, status, vehicle_label)
values ('UUID_DEL_USUARIO', 'offline', 'Taxi 1')
on conflict (user_id) do nothing;
```

## 2. Claves de Google Maps recomendadas

Crear claves separadas:

1. **Web**: restringida por `HTTP referrers` para la central del operador.
2. **Android**: restringida por package + SHA-1.
3. **iOS**: restringida por bundle identifier.
4. **Server**: solo para Edge Functions; restringir por APIs (Routes API y Geocoding API).

No subir la clave de servidor al repositorio.

## 3. APIs de Google a habilitar

- Maps JavaScript API
- Maps SDK for Android
- Maps SDK for iOS
- Geocoding API
- Routes API

## 4. Variables de entorno

Copiar `.env.example` y cargar los valores correspondientes.

En `apps/operator/.env`:

```env
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
VITE_GOOGLE_MAPS_WEB_KEY=...
```

En `apps/driver/.env` y `apps/passenger/.env`:

```env
EXPO_PUBLIC_SUPABASE_URL=...
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
EXPO_PUBLIC_GOOGLE_MAPS_ANDROID_KEY=...
EXPO_PUBLIC_GOOGLE_MAPS_IOS_KEY=...
```

## 5. Edge Functions

Con Supabase CLI:

```bash
supabase secrets set GOOGLE_MAPS_SERVER_KEY=TU_CLAVE_DE_SERVIDOR
supabase functions deploy geocode
supabase functions deploy route
```

## 6. Instalar y ejecutar

Desde la raíz:

```bash
npm install
```

Operador web:

```bash
npm run operator
```

Chofer:

```bash
npm run driver
```

Pasajero:

```bash
npm run passenger
```

## 7. Importante para ubicación en segundo plano

Expo Go sirve para probar la mayor parte del MVP, pero el seguimiento real en segundo plano requiere un **development build / EAS Build** con permisos nativos de ubicación. Para producción conviene probar Android físico desde el principio.

## Próximas mejoras recomendadas

- Autocompletado de direcciones con Places API.
- Cálculo automático del taxi más cercano con Route Matrix.
- Tarifas y estimación de precio.
- Push notifications.
- Historial y calificaciones.
- Foto de DNI y documentos del chofer en Supabase Storage.
- Botón SOS / incidentes.
- Navegación externa con Google Maps o Waze.
- Auditoría de eventos y panel de métricas.
