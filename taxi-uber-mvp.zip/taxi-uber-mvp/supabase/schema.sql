-- ============================================================
-- TAXI / UBER-LIKE MVP - SUPABASE SCHEMA
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'passenger' check (role in ('passenger','driver','operator')),
  full_name text,
  phone text,
  address text,
  notes text,
  dni_front_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.drivers (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  status text not null default 'offline' check (status in ('offline','available','busy')),
  vehicle_label text,
  plate text,
  updated_at timestamptz not null default now()
);

create table if not exists public.driver_locations (
  driver_id uuid primary key references public.drivers(user_id) on delete cascade,
  lat double precision not null,
  lng double precision not null,
  heading double precision,
  speed double precision,
  accuracy double precision,
  updated_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id) on delete restrict,
  driver_id uuid references public.drivers(user_id) on delete set null,
  pickup_address text,
  pickup_lat double precision not null,
  pickup_lng double precision not null,
  destination_address text not null,
  destination_lat double precision not null,
  destination_lng double precision not null,
  status text not null default 'requested' check (
    status in ('requested','assigned','driver_en_route','arrived','in_trip','completed','cancelled')
  ),
  distance_meters integer,
  duration_seconds integer,
  created_at timestamptz not null default now(),
  assigned_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  updated_at timestamptz not null default now()
);

create index if not exists trips_passenger_idx on public.trips(passenger_id, created_at desc);
create index if not exists trips_driver_idx on public.trips(driver_id, created_at desc);
create index if not exists trips_status_idx on public.trips(status, created_at desc);

-- ------------------------------------------------------------
-- updated_at helper
-- ------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_profiles_updated_at on public.profiles;
create trigger set_profiles_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists set_drivers_updated_at on public.drivers;
create trigger set_drivers_updated_at before update on public.drivers
for each row execute function public.set_updated_at();

drop trigger if exists set_trips_updated_at on public.trips;
create trigger set_trips_updated_at before update on public.trips
for each row execute function public.set_updated_at();

-- ------------------------------------------------------------
-- Create profile automatically on signup
-- ------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, role, full_name, phone)
  values (
    new.id,
    'passenger',
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- ------------------------------------------------------------
-- Role helper functions (avoid recursive RLS checks)
-- ------------------------------------------------------------
create or replace function public.is_operator()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'operator'
  );
$$;

create or replace function public.is_driver()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'driver'
  );
$$;

-- ------------------------------------------------------------
-- RLS
-- ------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.drivers enable row level security;
alter table public.driver_locations enable row level security;
alter table public.trips enable row level security;

-- Profiles
DROP POLICY IF EXISTS "profiles read own or operator" ON public.profiles;
CREATE POLICY "profiles read own or operator"
ON public.profiles FOR SELECT TO authenticated
USING (id = auth.uid() OR public.is_operator());

-- Profile editing is intentionally not exposed directly in this MVP.
-- This prevents a passenger from changing their own role to driver/operator.
DROP POLICY IF EXISTS "profiles update own" ON public.profiles;

-- Drivers
DROP POLICY IF EXISTS "drivers readable" ON public.drivers;
CREATE POLICY "drivers readable"
ON public.drivers FOR SELECT TO authenticated
USING (
  public.is_operator()
  OR user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.trips t
    WHERE t.driver_id = drivers.user_id
      AND t.passenger_id = auth.uid()
      AND t.status NOT IN ('completed','cancelled')
  )
);

DROP POLICY IF EXISTS "driver updates self" ON public.drivers;
CREATE POLICY "driver updates self"
ON public.drivers FOR UPDATE TO authenticated
USING (user_id = auth.uid() AND public.is_driver())
WITH CHECK (user_id = auth.uid() AND public.is_driver());

DROP POLICY IF EXISTS "operator inserts drivers" ON public.drivers;
CREATE POLICY "operator inserts drivers"
ON public.drivers FOR INSERT TO authenticated
WITH CHECK (public.is_operator());

-- Driver locations
DROP POLICY IF EXISTS "locations readable" ON public.driver_locations;
CREATE POLICY "locations readable"
ON public.driver_locations FOR SELECT TO authenticated
USING (
  public.is_operator()
  OR driver_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.trips t
    WHERE t.driver_id = driver_locations.driver_id
      AND t.passenger_id = auth.uid()
      AND t.status NOT IN ('completed','cancelled')
  )
);

DROP POLICY IF EXISTS "driver inserts own location" ON public.driver_locations;
CREATE POLICY "driver inserts own location"
ON public.driver_locations FOR INSERT TO authenticated
WITH CHECK (driver_id = auth.uid() AND public.is_driver());

DROP POLICY IF EXISTS "driver updates own location" ON public.driver_locations;
CREATE POLICY "driver updates own location"
ON public.driver_locations FOR UPDATE TO authenticated
USING (driver_id = auth.uid() AND public.is_driver())
WITH CHECK (driver_id = auth.uid() AND public.is_driver());

-- Trips
DROP POLICY IF EXISTS "trips readable by participants" ON public.trips;
CREATE POLICY "trips readable by participants"
ON public.trips FOR SELECT TO authenticated
USING (
  public.is_operator()
  OR passenger_id = auth.uid()
  OR driver_id = auth.uid()
);

DROP POLICY IF EXISTS "passenger creates trip" ON public.trips;
CREATE POLICY "passenger creates trip"
ON public.trips FOR INSERT TO authenticated
WITH CHECK (passenger_id = auth.uid() AND driver_id IS NULL AND status = 'requested');

DROP POLICY IF EXISTS "operator updates trips" ON public.trips;
CREATE POLICY "operator updates trips"
ON public.trips FOR UPDATE TO authenticated
USING (public.is_operator())
WITH CHECK (public.is_operator());

-- ------------------------------------------------------------
-- Safe RPC functions for actions
-- ------------------------------------------------------------
create or replace function public.driver_set_availability(p_status text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null or not public.is_driver() then
    raise exception 'Only drivers can change availability';
  end if;

  if p_status not in ('offline','available') then
    raise exception 'Invalid driver status';
  end if;

  if p_status = 'available' and exists (
    select 1 from public.trips
    where driver_id = auth.uid()
      and status in ('assigned','driver_en_route','arrived','in_trip')
  ) then
    raise exception 'Driver has an active trip';
  end if;

  update public.drivers
  set status = p_status
  where user_id = auth.uid();
end;
$$;

grant execute on function public.driver_set_availability(text) to authenticated;

create or replace function public.operator_assign_trip(p_trip_id uuid, p_driver_id uuid)
returns public.trips
language plpgsql
security definer
set search_path = public
as $$
declare
  result public.trips;
begin
  if auth.uid() is null or not public.is_operator() then
    raise exception 'Only operators can assign trips';
  end if;

  if not exists (
    select 1 from public.drivers where user_id = p_driver_id and status = 'available'
  ) then
    raise exception 'Driver is not available';
  end if;

  update public.trips
  set driver_id = p_driver_id,
      status = 'assigned',
      assigned_at = now()
  where id = p_trip_id and status = 'requested'
  returning * into result;

  if result.id is null then
    raise exception 'Trip is no longer available';
  end if;

  update public.drivers set status = 'busy' where user_id = p_driver_id;
  return result;
end;
$$;

grant execute on function public.operator_assign_trip(uuid, uuid) to authenticated;

create or replace function public.driver_set_trip_status(p_trip_id uuid, p_status text)
returns public.trips
language plpgsql
security definer
set search_path = public
as $$
declare
  result public.trips;
begin
  if auth.uid() is null or not public.is_driver() then
    raise exception 'Only drivers can change trip status';
  end if;

  if p_status not in ('driver_en_route','arrived','in_trip','completed') then
    raise exception 'Invalid trip status';
  end if;

  update public.trips
  set status = p_status,
      started_at = case when p_status = 'in_trip' and started_at is null then now() else started_at end,
      completed_at = case when p_status = 'completed' then now() else completed_at end
  where id = p_trip_id
    and driver_id = auth.uid()
    and status not in ('completed','cancelled')
  returning * into result;

  if result.id is null then
    raise exception 'Trip not found or not assigned to this driver';
  end if;

  if p_status = 'completed' then
    update public.drivers set status = 'available' where user_id = auth.uid();
  end if;

  return result;
end;
$$;

grant execute on function public.driver_set_trip_status(uuid, text) to authenticated;

create or replace function public.passenger_cancel_trip(p_trip_id uuid)
returns public.trips
language plpgsql
security definer
set search_path = public
as $$
declare
  result public.trips;
  old_driver uuid;
begin
  select driver_id into old_driver from public.trips
  where id = p_trip_id and passenger_id = auth.uid();

  update public.trips
  set status = 'cancelled', completed_at = now()
  where id = p_trip_id
    and passenger_id = auth.uid()
    and status in ('requested','assigned','driver_en_route')
  returning * into result;

  if result.id is null then
    raise exception 'Trip cannot be cancelled';
  end if;

  if old_driver is not null then
    update public.drivers set status = 'available' where user_id = old_driver;
  end if;

  return result;
end;
$$;

grant execute on function public.passenger_cancel_trip(uuid) to authenticated;

-- ------------------------------------------------------------
-- Realtime publication
-- ------------------------------------------------------------
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'driver_locations'
  ) then
    alter publication supabase_realtime add table public.driver_locations;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'trips'
  ) then
    alter publication supabase_realtime add table public.trips;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'drivers'
  ) then
    alter publication supabase_realtime add table public.drivers;
  end if;
end $$;
