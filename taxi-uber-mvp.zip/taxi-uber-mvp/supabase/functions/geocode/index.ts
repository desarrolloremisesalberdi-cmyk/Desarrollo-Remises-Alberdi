import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { address } = await req.json();
    if (!address || typeof address !== "string") {
      return Response.json({ error: "address is required" }, { status: 400, headers: cors });
    }

    const key = Deno.env.get("GOOGLE_MAPS_SERVER_KEY");
    if (!key) throw new Error("Missing GOOGLE_MAPS_SERVER_KEY");

    const params = new URLSearchParams({ address, region: "ar", key });
    const res = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?${params}`);
    const data = await res.json();

    if (!res.ok || data.status !== "OK" || !data.results?.length) {
      return Response.json(
        { error: data.error_message || data.status || "Address not found" },
        { status: 422, headers: cors },
      );
    }

    const first = data.results[0];
    return Response.json(
      {
        formattedAddress: first.formatted_address,
        lat: first.geometry.location.lat,
        lng: first.geometry.location.lng,
        placeId: first.place_id,
      },
      { headers: cors },
    );
  } catch (error) {
    return Response.json({ error: String(error) }, { status: 500, headers: cors });
  }
});
