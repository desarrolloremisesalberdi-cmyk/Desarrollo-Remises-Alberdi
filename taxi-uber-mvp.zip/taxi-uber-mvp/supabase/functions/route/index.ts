import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { origin, destination } = await req.json();
    if (origin?.lat == null || origin?.lng == null || destination?.lat == null || destination?.lng == null) {
      return Response.json({ error: "origin and destination are required" }, { status: 400, headers: cors });
    }

    const key = Deno.env.get("GOOGLE_MAPS_SERVER_KEY");
    if (!key) throw new Error("Missing GOOGLE_MAPS_SERVER_KEY");

    const res = await fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": "routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline",
      },
      body: JSON.stringify({
        origin: { location: { latLng: { latitude: origin.lat, longitude: origin.lng } } },
        destination: { location: { latLng: { latitude: destination.lat, longitude: destination.lng } } },
        travelMode: "DRIVE",
        routingPreference: "TRAFFIC_AWARE",
        computeAlternativeRoutes: false,
        languageCode: "es-419",
        units: "METRIC",
      }),
    });

    const data = await res.json();
    if (!res.ok) {
      return Response.json({ error: data }, { status: res.status, headers: cors });
    }

    const route = data.routes?.[0];
    if (!route) return Response.json({ error: "No route found" }, { status: 404, headers: cors });

    return Response.json(
      {
        distanceMeters: route.distanceMeters,
        duration: route.duration,
        encodedPolyline: route.polyline?.encodedPolyline,
      },
      { headers: cors },
    );
  } catch (error) {
    return Response.json({ error: String(error) }, { status: 500, headers: cors });
  }
});
